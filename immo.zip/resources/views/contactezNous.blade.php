Salut, je suis {{$data->name}} <br>
{{$data->email}} <br>
{{$data->phone}} <br>
{{$data->message}}