<?php $__env->startSection('title','Utilisateur'); ?>
  
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/admin/utilisateurs/utilisateur.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <main>
        <h1 class="title">Article</h1>
        <ul class="breadcrumbs">
            <li><a href="<?php echo e(route('dashboard')); ?>">Acceuil</a></li>
            <li class="divider">/</li>
            <li><a href="<?php echo e(route('utilisateurs.index')); ?>">Utilisateurs</a></li>
            <li class="divider">/</li>
            <li><a href="#" class="active">Utilisateur</a></li>
            <li class="divider">/</li>
            <li><?php echo e($utilisateur->id); ?></li>
        </ul>
        <section class="utilisateur_infos">
            <img src="<?php echo e(asset('assets/images/agent.webp')); ?>" alt="profile admin" class="infos_image">
            <h2><?php echo e($utilisateur->fname); ?> <?php echo e($utilisateur->lname); ?> <span class="role"><?php echo e($utilisateur->role->role); ?></span></h2>
            <p class="infos_desc">
                Lorem ipsum, dolor sit amet consectetur adipisicing elit. Corrupti, 
                aliquid alias quos praesentium incidunt ducimus eaque aliquam consequuntur expedita tenetur!
            </p>
            <div class="infos_perso">
                <h2>Coordonnées de Contact</h2>
                <span><i class="fa-solid fa-envelope"></i> <?php echo e($utilisateur->email); ?></span>
                <span><i class="fa-solid fa-phone"></i> <?php echo e($utilisateur->phone); ?></span>
            </div>
            <?php if($utilisateur->role_id == 3): ?>
                <div class="infos_perso">
                    <h2>Réseaux Sociaux</h2>
                    <a href=""><i class="fa-brands fa-whatsapp"></i> <?php echo e($utilisateur->whatsapp); ?></a>
                    <a href=""><i class="fa-brands fa-facebook"></i> Facebook</a>
                    <a href=""><i class="fa-brands fa-instagram"></i> Instagram</a>
                </div>
            <?php endif; ?>
            <div class="btns">
                <a href="<?php echo e(route('utilisateurs.edit',$utilisateur->id)); ?>" class="edit">Modifier</a>
                <form action="<?php echo e(route('utilisateurs.destroy',$utilisateur->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button class="danger" onclick="return confirm('Êtes-vous sûr de vouloir supprimer l\'Utilisateur <?php echo e($utilisateur->fname); ?> ?')">Supprimer</button>
                </form>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\immo\resources\views/admin/utilisateurs/utilisateur.blade.php ENDPATH**/ ?>