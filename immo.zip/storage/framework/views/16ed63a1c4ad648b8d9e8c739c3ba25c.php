<?php $__env->startSection('title', 'Utilisateurs'); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/admin/articles/articles.css')); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <main>
        <h1 class="title">Liste Des Utilisateurs</h1>
        <ul class="breadcrumbs">
            <li><a href="<?php echo e(route('dashboard')); ?>">Accueil</a></li>
            <li class="divider">/</li>
            <li><a href="#" class="active">Utilisateurs</a></li>
        </ul>

        <?php if(session('message')): ?>
            <section class="section_message" id="section_message">
                <?php echo e(session('message')); ?>

            </section>
        <?php endif; ?>

        <section class="table__header">
            <a href="<?php echo e(route('utilisateurs.create')); ?>" class="ajouter_article">Ajouter Utilisateur</a>
            <form method="POST" action="<?php echo e(route('utilisateurs.deleteAll')); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="supprimer_articles"
                    onclick="return confirm('Êtes-vous sûr de vouloir supprimer tous les utilisateurs ?')">Supprimer
                    Tous</button>
            </form>
            <div class="input-group">
                <input type="search" placeholder="Chercher Utilisateur...">
                <img src="<?php echo e(asset('assets/images/search.png')); ?>" alt="recherche icon">
            </div>
        </section>

        <?php if($utilisateurs->isEmpty()): ?>
            <p class="zero">Aucun Utilisateur trouvé</p>
        <?php else: ?>
            <section class="table__body">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nom & Prénom <span class="icon-arrow">&UpArrow;</span></th>
                            <th>Email <span class="icon-arrow">&UpArrow;</span></th>
                            <th>Téléphone <span class="icon-arrow">&UpArrow;</span></th>
                            <th>Rôle <span class="icon-arrow">&UpArrow;</span></th>
                            <th>Vérifié <span class="icon-arrow">&UpArrow;</span></th>
                            <th>Créé En <span class="icon-arrow">&UpArrow;</span></th>
                            <th>Actions</th>
                            <th>valider</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $utilisateurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $utilisateur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key + 1); ?></td>
                                <td><?php echo e($utilisateur->fname); ?> <?php echo e($utilisateur->lname); ?></td>
                                <td><?php echo e($utilisateur->email); ?></td>
                                <td><?php echo e($utilisateur->phone); ?></td>
                                <td>
                                    <p class="status categorie"><?php echo e($utilisateur->role->role); ?></p>
                                </td>
                                <td>
                                    <?php if($utilisateur->email_verified_at === null): ?>
                                        <i class="fa-solid fa-circle-xmark x"></i>
                                    <?php else: ?>
                                        <i class="fa-solid fa-circle-check check"></i>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($utilisateur->created_at->format('d-m-Y')); ?></td>
                                <td>
                                    <form method="POST" action="<?php echo e(route('utilisateurs.validate', $utilisateur->id)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <label>
                                            <input type="checkbox" name="validated" onchange="this.form.submit()"
                                                <?php echo e($utilisateur->email_verified_at ? 'checked' : ''); ?>>
                                            Valider
                                        </label>
                                    </form>

                                </td>
                                <td class="actions">
                                    <a href="<?php echo e(route('utilisateurs.show', $utilisateur->id)); ?>" class="voir"><i
                                            class="fa-regular fa-eye"></i></a>
                                    <a href="<?php echo e(route('utilisateurs.edit', $utilisateur->id)); ?>" class="edit"><i
                                            class="fa-regular fa-pen-to-square"></i></a>

                                    


                                    
                                    <form method="POST" action="<?php echo e(route('utilisateurs.destroy', $utilisateur->id)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button id="delete" class="delete"
                                            onclick="return confirm('Êtes-vous sûr de vouloir supprimer <?php echo e($utilisateur->lname); ?> <?php echo e($utilisateur->fname); ?> ?')">
                                            <i class="fa-solid fa-trash"></i>
                                        </button>
                                    </form>
                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </section>
        <?php endif; ?>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\immo\resources\views/admin/utilisateurs/utilisateurs.blade.php ENDPATH**/ ?>