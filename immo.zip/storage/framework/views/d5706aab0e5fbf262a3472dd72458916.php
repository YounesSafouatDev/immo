<?php $__env->startSection('title','Accueil'); ?>
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Section Banner -->    
    <section class="banner">
        <h1 class="banner_title">Louez ou Achetez en toute tranquillité avec notre Expertise</h1>
        <a href="<?php echo e(route('biens')); ?>" class="banner_link">PREMIUM IMMOBILIERS &nbsp;&nbsp;<i class="fa-solid fa-magnifying-glass" style="font-size: 18px;"></i></a>
    </section>
    <!-- Main -->
    <main class="main">
        <div class="text">
            <h2 class="bien_title">BIEN IMMOBILIER</h2>
            <p>
                Nos biens sont soigneusement sélectionnés pour répondre à 
                vos besoins et vous offrir le confort et la qualité de vie que vous méritez
            </p>
        </div>
        <section class="list_categories">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="category">
                    <img src="<?php echo e(asset('assets/images/'.$category->name.'.png')); ?>" alt="image immobilier" class="category_image" loading="lazy">
                    <div class="category_text">
                        <a href="<?php echo e(route('biens',$category->id)); ?>" class="category_link"><?php echo e($category->name); ?></a>
                        <span><?php echo e(count($category->annonces)); ?> annonces</span>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </section>
        <div class="properties_text">
            <h3 class="text_title">PREMIUM IMMOBILIERS</h3>
            <a href="<?php echo e(route('biens')); ?>" class="property_link">Tous</a>
        </div>
        <section class="properties_cards">
            <?php if($annonces->isNotEmpty()): ?>
                <?php $__currentLoopData = $annonces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $annonce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="property">
                        <div class="cover" style="background-image:  url('<?php echo e(asset('storage/annonces/'.$annonce->images->first()->path)); ?>');">
                            <h3><?php echo e(Str::limit($annonce->title,140)); ?>...</h3>
                            <span class="price"><?php echo e($annonce->price); ?> Dhs</span>
                           
                            <div class="card-back">
                                <a href="<?php echo e(route('bien',$annonce->id)); ?>" class="back_link">Plus detail</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <p>Aucune Annonce trouvé</p>
            <?php endif; ?>
            
        </section>
        <div class="annonceurs_text">
            <h3 class="text_title">ANNONCEURS</h3>
            <a href="" class="annonceur_link">Tous</a>
        </div>
        <section class="agents_cards">
            <?php if($annonceurs->isNotEmpty()): ?>
                <?php $__currentLoopData = $annonceurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $annonceur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card card0" style="background-image:url('<?php echo e(asset('assets/images/agent.webp')); ?>')">
                        <div class="border">
                            <a href="<?php echo e(route('biens')); ?>" class="agent_link"><?php echo e($annonceur->fname); ?> <?php echo e($annonceur->lname); ?></a>
                            <div class="icons">
                                <a href="https://wa.me/+212.<?php echo e($annonceur->whatsapp); ?>"><i class="fa fa-whatsapp" aria-hidden="true"></i></a>
                                <a href="<?php echo e($annonceur->instagram); ?>"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                                <a href="<?php echo e($annonceur->facebook); ?>"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <p>Aucun Annonceur trouvé</p>
            <?php endif; ?>
           
        </section>
        <div class="articles_text">
            <h3 class="text_title">NOUVEAUX ARTICLES</h3>
            <a href="" class="article_link">Tous</a>
        </div>
        <section class="articles_cards">
            <?php if($articles->isNotEmpty()): ?>
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class = "article">
                        <?php if($article->images->isNotEmpty()): ?>
                            <img src="<?php echo e(asset('storage/articles/'.$article->images->last()->path)); ?>" alt="<?php echo e($article->category->name); ?>">
                        <?php else: ?> 
                            <img src="<?php echo e(asset('assets/images/agent.webp')); ?>" alt="<?php echo e($article->category->name); ?>">
                        <?php endif; ?>
                        <div class="article-content">
                            <h3 class="article_title">
                                <?php echo e($article->title); ?>

                            </h3>
                            <p>
                                <?php echo Str::limit($article->description,250); ?>

                            </p>
                            <a href="" class="article_button">
                                Voir Plus &nbsp; 
                                <i class="fa-solid fa-arrow-right icon"></i>
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <p>Aucun Article trouvé</p>
            <?php endif; ?>
        </section>
        
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\immo\resources\views/welcome.blade.php ENDPATH**/ ?>