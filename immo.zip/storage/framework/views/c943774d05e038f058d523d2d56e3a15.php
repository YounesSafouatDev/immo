<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/admin/dashboard.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <!-- MAIN -->
    <main>
        <h1 class="title">Tableau de Bord</h1>
        <ul class="breadcrumbs">
            <li><a href="<?php echo e(route('dashboard')); ?>">Acceuil</a></li>
            <li class="divider">/</li>
            <li><a href="#" class="active">Tableau de Bord</a></li>
        </ul>
        <div class="info-data">
            <!-- Annonces Card -->
            <div class="card">
                <div class="head">
                    <div>
                        <h2><?php echo e(isset($annonces) ? $annonces->count() : 0); ?></h2>
                        <p>Annonces</p>
                    </div>
                </div>
            </div>

            <!-- Utilisateurs Card -->
            <div class="card">
                <div class="head">
                    <div>
                        <h2><?php echo e(isset($utilisateurs) ? $utilisateurs->count() : 0); ?></h2>
                        <p>Utilisateurs</p>
                    </div>
                </div>
            </div>

            <!-- Articles Card -->
            <div class="card">
                <div class="head">
                    <div>
                        <h2><?php echo e(isset($articles) ? $articles->count() : 0); ?></h2>
                        <p>Articles</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Utilisateurs Table -->
        <table>
            <caption>Liste Des Utilisateurs</caption>
            <thead>
                <tr>
                    <th scope="col" class="id">#</th>
                    <th scope="col">Nom</th>
                    <th scope="col">Email</th>
                    <th scope="col">Téléphone</th>
                    <th scope="col">Rôle</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $utilisateurs ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $utilisateur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td scope="row" data-label="Id"><?php echo e($key + 1); ?></td>
                        <td data-label="Nom"><?php echo e($utilisateur->lname); ?></td>
                        <td data-label="Email"><?php echo e($utilisateur->email); ?></td>
                        <td data-label="Téléphone"><?php echo e($utilisateur->phone); ?></td>
                        <td data-label="Rôle"><?php echo e($utilisateur->role->role); ?></td>
                        <td data-label="actions" class="actions">
                            <a href="<?php echo e(route('utilisateurs.show', $utilisateur->id)); ?>" class="voir"><i
                                    class="fa-regular fa-eye"></i></a>
                            <a href="<?php echo e(route('utilisateurs.edit', $utilisateur->id)); ?>" class="edit"><i
                                    class="fa-regular fa-pen-to-square"></i></a>
                            <form method="POST" action="<?php echo e(route('utilisateurs.destroy', $utilisateur->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button id="delete" class="delete"
                                    onclick="return confirm('Êtes-vous sûr de vouloir supprimer <?php echo e($utilisateur->lname); ?> <?php echo e($utilisateur->fname); ?> ?')">
                                    <i class="fa-solid fa-trash"></i></button>
                            </form>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6">Aucun utilisateur trouvé.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <a href="<?php echo e(route('utilisateurs.index')); ?>" class="voirplus">Voir Plus</a>

        <!-- Annonces Table -->
        <table>
            <caption>Liste Des Annonces</caption>
            <thead>
                <tr>
                    <th scope="col" class="id">#</th>
                    <th scope="col">Titre</th>
                    <th scope="col">Description</th>
                    <th scope="col">Nom Annonceur</th>
                    <th scope="col">Valide</th>
                    <th scope="col">Premuim</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $annonces ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $annonce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td scope="row" data-label="Id"><?php echo e($key + 1); ?></td>
                        <td data-label="Titre"><?php echo e($annonce->title); ?></td>
                        <td data-label="Description"><?php echo Str::limit($annonce->description, 20); ?></td>
                        <td data-label="Nom Annonceur">Hilali</td>
                        <td data-label="Valide">
                            <?php if($annonce->is_valid): ?>
                                <i class="fa-solid fa-check valide"></i>
                            <?php else: ?>
                                <i class="fa-solid fa-minus non"></i>
                            <?php endif; ?>
                        </td>
                        <td data-label="Premuim">
                            <?php if($annonce->is_premium): ?>
                                <i class="fa-solid fa-check valide"></i>
                            <?php else: ?>
                                <i class="fa-solid fa-minus non"></i>
                            <?php endif; ?>
                        </td>
                        <td data-label="actions" class="actions">
                            <a href="<?php echo e(route('annonces.show', $annonce->id)); ?>" class="voir"><i
                                    class="fa-regular fa-eye"></i></a>
                            <a href="<?php echo e(route('annonces.edit', $annonce->id)); ?>" class="edit"><i
                                    class="fa-regular fa-pen-to-square"></i></a>
                            <form method="POST" action="<?php echo e(route('annonces.destroy', $annonce->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button id="delete" class="delete"
                                    onclick="return confirm('Êtes-vous sûr de vouloir supprimer <?php echo e($annonce->title); ?>?')">
                                    <i class="fa-solid fa-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6">Aucune annonce trouvée.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <a href="<?php echo e(route('annonces.index')); ?>" class="voirplus">Voir Plus</a>

        <!-- Articles Table -->
        <table>
            <caption>Liste Des Articles</caption>
            <thead>
                <tr>
                    <th scope="col" class="id">#</th>
                    <th scope="col">Titre</th>
                    <th scope="col">Description</th>
                    <th scope="col">Date Creation</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $articles ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td scope="row" data-label="Id"><?php echo e($key + 1); ?></td>
                        <td data-label="Titre"><?php echo e($article->title); ?></td>
                        <td data-label="Description"><?php echo Str::limit($article->description, 100); ?></td>
                        <td data-label="Date Creation"><?php echo e($article->created_at->format('d M Y')); ?></td>
                        <td data-label="actions" class="actions">
                            <a href="<?php echo e(route('articles.show', $article->id)); ?>" class="voir"><i
                                    class="fa-regular fa-eye"></i></a>
                            <a href="<?php echo e(route('articles.edit', $article->id)); ?>" class="edit"><i
                                    class="fa-regular fa-pen-to-square"></i></a>
                            <form method="POST" action="<?php echo e(route('articles.destroy', $article->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button id="delete" class="delete"
                                    onclick="return confirm('Êtes-vous sûr de vouloir supprimer <?php echo e($article->title); ?>?')">
                                    <i class="fa-solid fa-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6">Aucun article trouvé.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <a href="<?php echo e(route('articles.index')); ?>" class="voirplus">Voir Plus</a>
    </main>
    <!-- MAIN -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\immo\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>