<?php $__env->startSection('title','Se Connecter'); ?>
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/login.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/js/login.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Section Login -->
    <?php if(session('message')): ?>
        <section class="section_message" id="section_message">
            <?php echo e(session('message')); ?>

        </section>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <section class="section_error" id="section_message">
            <?php echo e(session('error')); ?>

        </section>
    <?php endif; ?>
    <section class="login">
        <img src="<?php echo e(asset('assets/images/login.webp')); ?>" alt="login image" class="form_image">
        <div class="login_form">
            <h1 class="form_title">BIENVENUE</h1>
            <form action="<?php echo e(route('login')); ?>" class="sign_in" method="post">
                <?php echo csrf_field(); ?>
                <div class="sign_group">
                    <label for="email">Email <span class="required">*</span> </label>
                    <input type="email" name="email" id="email" class="group_input" required placeholder="Votre E-mail" 
                        <?php if(isset($_COOKIE['email'])): ?>
                            value="<?php echo e($_COOKIE['email']); ?>"
                        <?php else: ?>
                            value="<?php echo e(old('email')); ?>"
                        <?php endif; ?>
                    >
                    <span class="message_email" id="message_email"><?php echo e($errors->first('email')); ?></span>
                </div>
                <div class="sign_group">
                    <label for="password">Mot De Passe <span class="required">*</span></label>
                    <input type="password" name="password" id="password" class="group_input" required placeholder="********" >
                    <span class="message_password" id="message_password"><?php echo e($errors->first('password')); ?></span>
                </div>
                <div class="sign_check_link">
                    <div class="check">
                        <input type="checkbox" name="remember" id="remember" class="remember" 
                            <?php if(isset($_COOKIE['email'])): ?>
                                checked=""
                            <?php endif; ?>
                        >
                        <label for="remember">Remember me</label>
                    </div>
                    <a href="<?php echo e(route('forget')); ?>" class="forgot">Mot de passe oublié ?</a>
                </div>
                <input type="submit" value="Se Connecter" class="btn_form" id="btn_form">
            </form>
            <p class="account">Vous n'avez pas de compte ?<a href="<?php echo e(route('show_register')); ?>"> S'inscrire</a></p>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\immo\resources\views/auth/login.blade.php ENDPATH**/ ?>